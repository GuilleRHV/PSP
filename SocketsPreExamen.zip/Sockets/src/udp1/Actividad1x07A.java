package udp1;


import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;

public class Actividad1x07A {

	public static void main(String[] args) throws SocketException {
		// TODO Auto-generated method stub
		InetSocketAddress addr = new InetSocketAddress("localhost", 50000);
		DatagramSocket datagramSocket = new DatagramSocket(50000);
		try {
			// creadno socket datagrama

			
			/*tcp:
mas fiable, ordenado
Udp:
menos fiable, sin ordenar, tarda menos
			 * */
// Recibiendo mensaje
			while (true) {
				byte[] mensaje = new byte[4];
				DatagramPacket datagrama1 = new DatagramPacket(mensaje, 4); // o mensaje.lenght
				System.out.println("Antes de recibir");
				datagramSocket.receive(datagrama1);
				//System.out.println("Mensaje recibido");
				// enviamos mensaje
				String saludo = new String(mensaje);
				String respuesta = "";
				if (saludo.equals("hola")) {
					respuesta = "�COmo te llamas?";

				}
				System.out.println("Enviarr");
				// get bytes si tenemos una cadena
				DatagramPacket datagrama2 = new DatagramPacket(respuesta.getBytes(), respuesta.getBytes().length,
						datagrama1.getAddress(), datagrama1.getPort());
				datagramSocket.send(datagrama2);
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		finally {
			datagramSocket.close();
		}
	}

}
