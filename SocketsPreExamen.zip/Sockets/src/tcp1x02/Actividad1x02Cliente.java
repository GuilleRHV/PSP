package tcp1x02;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Actividad1x02Cliente {

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
String host = "localhost";
int puerto = 60037;
Socket cliente = null; 

PrintWriter fsalida = null;
BufferedReader fentrada = null;
//fentrada

try {
	cliente = new Socket(host, puerto); 
	fsalida = new PrintWriter(cliente.getOutputStream(), true);
	fentrada =  new BufferedReader (new InputStreamReader(cliente.getInputStream())); 
	BufferedReader in = new BufferedReader (new InputStreamReader(System.in));
	String cadena="";


	System.out.println("Escribe una frase");
	
	 cadena = in.readLine();
	 fsalida.println(cadena);
	String mayus = fentrada.readLine();
	System.out.println(mayus);
	//pregunta = fentrada.readLine();
	fsalida.close(); 
	fentrada.close(); 


	cliente.close(); 
} catch (Exception e) {
	// TODO: handle exception
}
finally {
	fsalida.close();
	fentrada.close();
	cliente.close();
}
	}

}
