package tcp1x02;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class Actividad1x02Servidor {

    public static void main(String[] args) throws IOException {
        int numpuerto = 60037;
        ServerSocket servidor = null;
        PrintWriter fsalida = null;
        BufferedReader fentrada = null;
        try {
           
            servidor = new ServerSocket(numpuerto);
            System.out.println("Esperando conexion");
            Socket clienteConectado = servidor.accept();
            System.out.println("CLiente conectado");
            fsalida = new PrintWriter(clienteConectado.getOutputStream(), true);
        	fentrada =  new BufferedReader (new InputStreamReader(clienteConectado.getInputStream())); 
            String cadena ="";
            while ((cadena = fentrada.readLine()) !=null) {
            	fsalida.println(cadena.toUpperCase());
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (servidor != null && !servidor.isClosed()) {
                servidor.close();
            }
        }
    }
}
