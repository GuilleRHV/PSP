package tcpencuesta;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClienteEncuesta {

	public static void main(String[] args) throws UnknownHostException, IOException {
		// TODO Auto-generated method stub
String host = "localhost";
int puerto = 60035;
Socket cliente = null; 

PrintWriter fsalida = null;
BufferedReader fentrada = null;
//fentrada

try {
	cliente = new Socket(host, puerto); 
	fsalida = new PrintWriter(cliente.getOutputStream(), true);
	fentrada =  new BufferedReader (new InputStreamReader(cliente.getInputStream())); 
	BufferedReader in = new BufferedReader (new InputStreamReader(System.in));
	String pregunta;
	String respuesta;
	System.out.println("Cliente: antes de leer");
	pregunta = fentrada.readLine();
	while(pregunta.startsWith("�")) {
		
		System.out.println(pregunta);
		respuesta = in.readLine();
		fsalida.println(respuesta);
		pregunta = fentrada.readLine();
	}

	System.out.println("Has recibido "+pregunta);
	//pregunta = fentrada.readLine();
	fsalida.close(); 
	fentrada.close(); 
	System.out.println("Fin del env�o... "); 

	cliente.close(); 
} catch (Exception e) {
	// TODO: handle exception
}
finally {
	fsalida.close();
	fentrada.close();
	cliente.close();
}
	}

}
