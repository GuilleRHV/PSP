package tcp1x03;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class Actividad1x03Cliente {

    public static void main(String[] args) {
        String host = "localhost";
        int puerto = 60041;
        Socket cliente = null;

        try {
            cliente = new Socket(host, puerto);
            DataOutputStream fsalida = new DataOutputStream(cliente.getOutputStream());
            DataInputStream fentrada = new DataInputStream(cliente.getInputStream());

            // Leer desde el teclado
            System.out.println("Escribe una numero entero:");
            BufferedReader in = new BufferedReader (new InputStreamReader(System.in));
            String cadena = in.readLine();

            
            // Enviar al servidor
            fsalida.writeUTF(cadena);

            // Recibir respuesta del servidor
            String numeroalcuadrado = fentrada.readUTF();
            System.out.println("Respuesta del servidor: " + numeroalcuadrado);

        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (cliente != null && !cliente.isClosed()) {
                    cliente.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
