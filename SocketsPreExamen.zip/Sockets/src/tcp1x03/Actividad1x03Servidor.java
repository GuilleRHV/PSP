package tcp1x03;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

public class Actividad1x03Servidor {

    public static void main(String[] args) {
        int numpuerto = 60041;
        ServerSocket servidor = null;

        try {
            servidor = new ServerSocket(numpuerto);
            System.out.println("Esperando conexi�n...");

            Socket clienteConectado = servidor.accept();
            System.out.println("Cliente conectado.");

            DataOutputStream fsalida = new DataOutputStream(clienteConectado.getOutputStream());
            DataInputStream fentrada = new DataInputStream(clienteConectado.getInputStream());

            String cadena = "";

           
            // Recibir mensaje del cliente
            cadena = fentrada.readUTF();
            System.out.println("Mensaje recibido del cliente: " + cadena);

            // Enviar respuesta al cliente
            int numerocadena = Integer.parseInt(cadena);
             numerocadena = numerocadena*numerocadena;
            fsalida.writeUTF(String.valueOf(numerocadena));

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (servidor != null && !servidor.isClosed()) {
                    servidor.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
