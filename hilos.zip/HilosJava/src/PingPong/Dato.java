package PingPong;


public class Dato {
	private String cadena = "Ping";
	private boolean disponible = false; //elemento vacía
	
	public synchronized String get(){
		while(!disponible){
			try{
				wait();
			}
			catch(InterruptedException e){
	        	System.err.println(e.toString());
	        }
		}
		disponible = false;
	
		notifyAll();
		return cadena;
		 
	}

	
	public synchronized void set (){
		while(disponible){
			try{
				wait();
			}
			catch(InterruptedException e){
	        	System.err.println(e.toString());
	        }
		}
		if (cadena.equals("Ping")) {
			cadena = "Pong";
		}else if(cadena.equals("Pong")) {
			cadena ="Ping";
		}
	
		disponible = true;
		notifyAll();
	}

	public String getCadena() {
		return cadena;
	}

	public void setCadena(String cadena) {
		this.cadena = cadena;
	}
	
	
}