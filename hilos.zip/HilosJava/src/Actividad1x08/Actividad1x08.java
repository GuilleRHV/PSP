package Actividad1x08;

public class Actividad1x08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Barrera b = new Barrera(5);
		Coche c1 = new Coche(2, b);
		Coche c2 = new Coche(8, b);
		Coche c3 = new Coche(43, b);
		Coche c4 = new Coche(82, b);
		Coche c5 = new Coche(21, b);
		Coche c6 = new Coche(68, b);
		c1.run();
		c2.run();
		c3.run();
		c4.run();
		c5.run();
		c6.run();
	}

}
