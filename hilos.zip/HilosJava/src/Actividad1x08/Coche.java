package Actividad1x08;

public class Coche extends Thread {
int id;
Barrera barrera;
public Coche(int id, Barrera barrera) {
	super();
	this.id = id;
	this.barrera = barrera;
}
@Override
public void run() {
	
		
			barrera.permitirentrada(id);
		
	
	
	
}

}
