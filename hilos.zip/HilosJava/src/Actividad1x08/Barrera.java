package Actividad1x08;

public class Barrera extends Thread{
	int plazas[];
	int plazaslibres;
	public Barrera(int totalplazas) {
		super();
		this.plazas = new int[totalplazas];
		this.plazaslibres = totalplazas;
	}
	
	
	public void permitirentrada(int idcoche) {
		boolean entrado = false;
		
		for (int i = 0; i<plazas.length;i++) {
			if(!entrado) {
				System.out.println("El coche "+idcoche+" intenta aparcar");
				if (plazas[i]==0) {
					entrado=true;
					plazas[i] = idcoche;
					System.out.println("El coche "+idcoche+" ha aparcado en el sitio "+i);
					plazaslibres--;
					for (int u : plazas) {
						System.out.print("["+u+"] ");
					}
				}
			}
		}
		
		
		
	}
	
	public void permitirsalida(int posicion) {
		synchronized (plazas) {
			plazas[posicion] = 0;
			notify();
			plazaslibres++;
		}
		
		
		
	}
	
	
	@Override
	public void run() {
		
		
		
	}
	
	
}
