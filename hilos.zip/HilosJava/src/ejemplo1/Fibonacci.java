package ejemplo1;
import entrada.Teclado;
public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numero,fibo1,fibo2,i;
		  
        do{
            System.out.print("Introduce numero mayor que 1: ");
            numero = Teclado.leerEntero("Introduce n:");
        }while(numero<=1);
  
        System.out.println("Los " + numero + " primeros términos de la serie de Fibonacci son:");                 

        fibo1=1;
        //Es un auxiliar
        fibo2=1;
        int cont = 0;
        System.out.print(fibo1 + " ");
        for(i=2;i<=numero;i++){
            System.out.print(fibo2 + " ");
            fibo2 = fibo1 + fibo2;
            fibo1 = fibo2 - fibo1;
            cont = cont+ fibo1+fibo2;
        }
        System.out.println(cont);
        
        /*
        OtroHilo hilo1 = new OtroHilo("Hilo 1");
		OtroHilo hilo2 = new OtroHilo("Hilo 2");
		hilo1.start();
		hilo1.join();
		hilo2.start();
		hilo2.join();*/
	}
	

}
