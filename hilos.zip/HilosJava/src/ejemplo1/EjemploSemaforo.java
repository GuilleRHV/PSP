package ejemplo1;

import java.util.concurrent.Semaphore;

class DatoCompartido2 {
	private int numero;
	
	public DatoCompartido2(int num) {
		numero = num; 
	}
	
	public int getNumero(){
		return numero;
	}
	
	public void setNumero (int num){
		numero = num; 
	}
	
	public String toString() {
		return String.valueOf(numero);
	}
}


class ClaseSumar2 extends Thread{
	DatoCompartido2 dato;
	Semaphore semaforo;
	
	ClaseSumar2(Semaphore semaforo, 
			DatoCompartido2 dato){
		this.dato = dato;
		this.semaforo = semaforo;
	}
	public void run() {
		for(int i = 0; i<5; i++) {
			try {
				semaforo.acquire();
				dato.setNumero(dato.getNumero() + 1);
				System.out.println("Dato en sumar vale: " + dato.getNumero());
				sleep(10);
				semaforo.release();
			} catch (InterruptedException e) { 
				System.out.println("ClaseSumar interrumpida");
			}
		}
		System.out.println("Dato fin sumar vale: " + dato.getNumero()); 
	}
}

class ClaseRestar2 extends Thread{
	DatoCompartido2 dato;
	Semaphore semaforo;
	
	ClaseRestar2(Semaphore semaforo, DatoCompartido2 dato){
		this.dato = dato;
		this.semaforo = semaforo;
	}
	public void run() {
		for(int i = 0; i<5; i++){
			try {
				semaforo.acquire();
				dato.setNumero(dato.getNumero() - 1);
				System.out.println("Dato en restar vale: " + dato.getNumero());
				sleep(10);
				semaforo.release();
			} catch (InterruptedException e) { 
				System.out.println("ClaseRestar interrumpida");
			}
		}
		System.out.println("Dato fin restar vale: " + dato.getNumero()); 
	}
}

public class EjemploSemaforo {

	public static void main(String[] args) throws InterruptedException {

		Semaphore semaforo= new Semaphore(1);
		DatoCompartido2 dato = new DatoCompartido2(0);
		ClaseSumar2 hilo1 = new ClaseSumar2(semaforo, dato);
		ClaseRestar2 hilo2 = new ClaseRestar2(semaforo, dato);
		hilo1.start();
		hilo2.start(); 
	}

}