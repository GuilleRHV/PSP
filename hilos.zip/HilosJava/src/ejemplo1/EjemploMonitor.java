package ejemplo1;


class DatoCompartido1 {
	private int numero;
	
	public DatoCompartido1(int num) {
		numero = num; 
	}
	
	public int getNumero(){
		return numero;
	}
	
	public void setNumero (int num){
		numero = num; 
	}
	
	public String toString() {
		return String.valueOf(numero);
	}
}


class ClaseSumar1 extends Thread{
	DatoCompartido dato;
	
	ClaseSumar1(DatoCompartido dato){
		this.dato = dato;
	}
	public void run() {
		for(int i = 0; i<10; i++) {
			try {
				synchronized (dato){
					dato.setNumero(dato.getNumero() + 1);
					System.out.println("Dato en sumar vale: " + dato.getNumero()); 
				}
				sleep(10);
			} catch (InterruptedException e) { 
				System.out.println("ClaseSumar interrumpida");
			}
		}
		System.out.println("Dato fin sumar vale: " + dato.getNumero()); 	
	}
}

class ClaseRestar1 extends Thread{
	DatoCompartido dato; 
	
	ClaseRestar1(DatoCompartido dato){
		this.dato = dato;
	}
	public void run() {
		for(int i = 0; i<10; i++){
			try {
				synchronized (dato){
					dato.setNumero(dato.getNumero() - 1);
					System.out.println("Dato en restar vale: " + dato.getNumero()); 
				}
				sleep(10); 
			} catch (InterruptedException e) { 
				System.out.println("ClaseRestar interrumpida");
			}
		}
		System.out.println("Dato fin restar vale: " + dato.getNumero()); 	
	}
}

public class EjemploMonitor {

	public static void main(String[] args) throws InterruptedException {

		DatoCompartido dato = new DatoCompartido(0);
		ClaseSumar1 hilo1 = new ClaseSumar1(dato);
		ClaseRestar1 hilo2 = new ClaseRestar1(dato);
		hilo1.start();
		hilo2.start();
	}

}