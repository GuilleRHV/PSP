package ejemplo1;

public class Ejemplo {
	public static void main(String[] args) {
		System.out.println("Valor devuelto desde el ejemplo");
	}
}
