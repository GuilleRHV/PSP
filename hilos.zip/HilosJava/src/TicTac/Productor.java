package TicTac;


public class Productor extends Thread
{
    private Dato dato;
    private int num;
 
   
    public Productor(Dato c) 
    {
        this.dato = c;
     
    }
 
    public void run() 
    {
    	for (int i=0; i<15;i++){
    		dato.set();
    		
    	}
        try{
        	sleep(100);
        }
        catch(InterruptedException e){
        	System.err.println(e.toString());
        }
    }
}