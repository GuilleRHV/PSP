package diasSemana;

public class Consumidor extends Thread
{
    private Dato dato;
    private int num;
 
   
    public Consumidor(Dato c) 
    {
        this.dato = c;
     
    }
 
    public void run() 
    {
    	String valor = "";
    	for (int i=0; i<5;i++){
    		valor = dato.get();
    		System.out.println(valor);
    	}
    	
    	/*
    	for (int i=0; i<5;i++){
    		dato.set();
    		System.out.println(dato.getCadena());
    	}
        try{
        	sleep(100);
        }
        catch(InterruptedException e){
        	System.err.println(e.toString());
        }*/
    }
}