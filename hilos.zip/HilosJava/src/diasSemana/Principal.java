package diasSemana;


public class Principal {

	public static void main(String[] args) {
		Dato dato = new Dato();
		Productor p = new Productor(dato);
		Consumidor c = new Consumidor(dato);
		p.start();
		c.start();

	}

}