package ProblemaProductorConsumidor;


public class Compartido {
	private int numero;
	private boolean disponible = false; //elemento vacía
	
	public synchronized int get(){
		while(!disponible){
			try{
				wait();
			}
			catch(InterruptedException e){
	        	System.err.println(e.toString());
	        }
		}
		disponible = false;
		notifyAll();
		return numero;
		 
	}
	
	public synchronized void set (int n){
		while(disponible){
			try{
				wait();
			}
			catch(InterruptedException e){
	        	System.err.println(e.toString());
	        }
		}
		numero = n;
		disponible = true;
		notifyAll();
	}
}