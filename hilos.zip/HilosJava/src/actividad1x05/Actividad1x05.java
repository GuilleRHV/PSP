package actividad1x05;

import java.util.concurrent.Semaphore;

public class Actividad1x05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Semaphore semaforo = new Semaphore(0);
		Saludo sal1 = new Saludo(1,semaforo);
		Saludo sal2 = new Saludo(2, semaforo);
		sal1.start();
		sal2.start();
	}

}
