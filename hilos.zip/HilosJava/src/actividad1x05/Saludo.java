package actividad1x05;

import java.util.concurrent.Semaphore;

public class Saludo extends Thread {
	public int id;
	Semaphore semaforo;
	public Saludo(int id, Semaphore semaforo) {
		super();
		this.id = id;
		this.semaforo=semaforo;
	}

	@Override
	public void run() {
		try {
			if(id == 2) {
				System.out.println("id:" + this.id);
				// QUe continue
				semaforo.release();
			} else {
				//Espera
				semaforo.acquire();
				System.out.println("id:" + this.id);
				semaforo.release();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
	}
}
