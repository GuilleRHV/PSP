package Actividad1x08;

import java.util.Random;

public class Coche extends Thread {
int id;
Barrera barrera;
public Coche(int id, Barrera barrera) {
	super();
	this.id = id;
	this.barrera = barrera;
}
@Override
public void run() {
	try {
		Thread.sleep(new Random().nextInt(1000));
		System.out.println("COche "+id+" intenta entrar al parking");
		int plaza = barrera.permitirentrada(id);
		System.out.println("Coche "+id+ " aparcando en "+plaza);
		barrera.mostrarestado();
		Thread.sleep(new Random().nextInt(1000));
		barrera.permitirsalida(plaza);
		System.out.println("Coche "+id+" saliendo");
		barrera.mostrarestado();
	} catch (InterruptedException e) {
		// TODO: handle exception
		e.printStackTrace();
	}

		
	
}

}
