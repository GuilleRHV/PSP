package Actividad1x08;

public class Barrera extends Thread{
	int plazas[];
	int libres;
	public Barrera(int totalplazas) {
		super();
		this.plazas = new int[totalplazas];
		this.libres = totalplazas;
	}
	
	
	synchronized public int permitirentrada(int idcoche) throws InterruptedException {
	
		int plaza = 0;
		while (libres == 0) {
			System.out.println("Coche "+idcoche+" esperando");
			wait();
		}
		
		while(plazas[plaza] != 0) {
			plaza++;
		}
		plazas[plaza] = idcoche;
		libres--;
		return plaza;

		
		
	}
	
	synchronized public void permitirsalida(int posicion) {
	
		plazas[posicion] = 0;
		libres--;
		notifyAll();
		
		
	}
	
	public void mostrarestado()
	{
		System.out.print("Parking: ");
		for(int i = 0; i<plazas.length;i++) {
			System.out.print("["+plazas[i]+"]");
		}
	}
	
	
	
	
}
