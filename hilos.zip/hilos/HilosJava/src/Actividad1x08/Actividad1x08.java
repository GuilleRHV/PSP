package Actividad1x08;

public class Actividad1x08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int SITIOS = 5;
		final int NUM_COCHES = 10;
		Barrera b = new Barrera(SITIOS);
		Coche coches[] = new Coche[NUM_COCHES];
		for(int i = 0;i<coches.length;i++) {
			coches[i] = new Coche(i+1, b);
			coches[i].start();
		}
		try {
			for(int i = 0; i<coches.length;i++) {
				coches[i].join();
			}
		} catch (InterruptedException e) {
			// TODO: handle exception
			System.out.println("Main interrumpido");
		}
		
	}

}
