package udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class ClienteUDP {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		InetAddress destino = InetAddress.getLocalHost();
		int port = 50000;
		byte[] mensaje = new byte[1024];

		String saludo = "Enviamos saludo";
		mensaje = saludo.getBytes();

// Se construye el datagrama a enviar
		DatagramPacket envio = new DatagramPacket(mensaje, mensaje.length, destino, port);
		DatagramSocket socket = new DatagramSocket(55000); // puerto local
		System.out.println("Enviando el datagrama de longitud: " + mensaje.length);
		System.out.println("Host destino: " + destino.getHostName());
		System.out.println("IP destino: " + destino.getHostAddress());
		System.out.println("Puerto local del socket: "+socket.getLocalPort());
		System.out.println("Puerto al que envio: "+envio.getPort());
		
		// Se envia el datagrama
		socket.send(envio);
		socket.close();
	}

}
