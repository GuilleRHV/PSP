package udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class ServidorUDP {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		byte[] buffer = new byte[1024];
		DatagramSocket socket = new DatagramSocket(50000);
//Esperando datagrama
		System.out.println("Esperando datagrama....");

		DatagramPacket recibo = new DatagramPacket(buffer, buffer.length);
		socket.receive(recibo);

		int bytesRec = recibo.getLength(); // Se obtiene cantidad de bytes
		String paquete = new String(recibo.getData()); // Paso a string

		// Se visualiza la informacion
		System.out.println("Numeroo de bytes recibidos: " + bytesRec);
		System.out.println("Contenido del paquete: " + paquete.trim());
		System.out.println("Puerto origen del mensaje: " + recibo.getPort());

		System.out.println("IP de origen: " + recibo.getAddress().getHostAddress());
		System.out.println("Puesto destino del mensaje: " + socket.getLocalPort());
		socket.close();
	}

}
