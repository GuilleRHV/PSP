package udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;

public class ServidorUDP2 {
	public static void main(String[] args) {
	byte[] enviados = new byte[1024];
	byte[] recibidos = new byte[1024];
	DatagramSocket serverSocket = new DatagramSocket(50000);
	String cadena = "";
	// serverSocket=null;
	while(true) {
		recibidos = new byte[1024];
		DatagramPacket paquRecibido = new DatagramPacket(recibidos, recibidos.length);
		serverSocket.receive(paquRecibido);
		cadena = new String(paquRecibido.getData());
		
		//Se recibe datagrama
	
		InetAddress IPOrigen = paquRecibido.getAddress();
		int puerto = paquRecibido.getPort();
		System.out.println("ORigen: "+IPOrigen);
		System.out.println("Mensaje rexibido "+cadena.trim());
		// Pasar cadena a mayusculas
		String mayusculas = cadena.trim().toUpperCase();
		enviados = mayusculas.getBytes();

	}
	
	serverSocket.close();
}
}
