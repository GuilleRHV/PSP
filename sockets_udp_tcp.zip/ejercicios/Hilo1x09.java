package ejercicios;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Hilo1x09 extends Thread {
Socket socket;

public Hilo1x09(Socket socket) {
	super();
	this.socket = socket;
}

@Override 
public void run() {
PrintWriter fsalida = null;
BufferedReader fentrada = null;

try {
	fsalida = new PrintWriter(socket.getOutputStream(), true);
	fentrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	String pregunta;
	String respuesta;
	for(int i = 0;i<3;i++) {
		pregunta = fentrada.readLine();
		respuesta = responder(pregunta);
		fsalida.printf(respuesta);
		
	}
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
finally {
	if(fsalida!=null) {
		fsalida.close();
	}
	if(fentrada != null) {
		try {
			fentrada.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}
}


private String responder(String pregunta) {
	String respuesta="";
	
	if(pregunta.equals("¿Que dia es?")) {
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/YYYY");
		respuesta = LocalDateTime.now().format(formato);
	}
	else if(pregunta.equals("¿Que hora es?")) {
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("HH:mm:ss");
		respuesta = LocalDateTime.now().format(formato);
	}
	else {
		respuesta = "No tengo la respuesta";
	}
	return respuesta;
	
	
}

}
