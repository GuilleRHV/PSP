package ejercicios;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor1x09 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
int numpuerto = 60001;
ServerSocket servidor = null;
Hilo1x09 hilo = null;
try {
	servidor = new ServerSocket(numpuerto);
	Socket clienteConectado;
	while(true) {
		System.out.println("Conectando...");
		clienteConectado = servidor.accept();
		
		hilo = new Hilo1x09 (clienteConectado);
		
		hilo.start();
	
	}
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
finally {
	if(servidor!=null) {
		servidor.close();
	}
	if(hilo!=null) {
		hilo.stop();
	}
}
	}

}
