package ejercicios;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

public class ServidorEncuesta {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
int numpuerto = 60001;
ServerSocket servidor = null;

try {
	ArrayList<Pregunta> preguntas = new ArrayList<>();
	preguntas.add(new Pregunta("¿Que edad tienes?"));
	preguntas.add(new Pregunta("¿Donde estudias?"));
	preguntas.add(new Pregunta("¿Cuanto mides?"));
	servidor = new ServerSocket(numpuerto);

	while(true) {
		Socket clienteConectado = servidor.accept();
		Hilo hilo = new Hilo(clienteConectado, preguntas);
	
		
		hilo.start();
	
	}
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
finally {
	if(servidor!=null) {
		servidor.close();
	}

}
	}

}



