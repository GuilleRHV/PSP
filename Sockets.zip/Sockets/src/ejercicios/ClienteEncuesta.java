package ejercicios;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;

public class ClienteEncuesta {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String host = "localhost";
int puerto = 60000;
Socker cliente = ;
PrintWriter fsalida = null;
BufferedReader fentrada = null;
//fentrada

try {
	fsalida = new PrintWriter(socket.getOutputStream());
	fentrada = new BufferedReader(new InputStreamReader(in));
	String pregunta;
	String respuesta;
	pregunta = fentrada.readline();
	while(pregunta.startsWith("¿")) {
		System.out.println(pregunta);
	}
} catch (Exception e) {
	// TODO: handle exception
}
	}

}
