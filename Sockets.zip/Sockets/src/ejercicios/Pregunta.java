package ejercicios;

public class Pregunta {
String texto;
int votossi;
int votosno;
public Pregunta(String texto) {
	super();
	this.votosno=0;
	this.votossi=0;
	this.texto = texto;
}
 public void sumarVotosSi() {
	 this.votossi++;
 }

 public void sumarVotosNo() {
	 this.votosno++;
 }
 
 public String getTexto() {
	 return this.texto;
 }
}
