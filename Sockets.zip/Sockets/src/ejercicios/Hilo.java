package ejercicios;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;

public class Hilo extends Thread {

	Socket socket;
	ArrayList<Pregunta> preguntas;

	public Hilo(Socket socket, ArrayList<Pregunta> preguntas) {
		super();
		this.socket = socket;
		this.preguntas = preguntas;
	}
publi void 
	public void run() {
		PrintWriter fsalida = null;
		BufferedReader fentrada = null;
		try {
			fsalida = new PrintWriter(socket.getOutputStream());
			fentrada = new BufferedReader(new InputStreamReader(in));
			String respuesta;
			for(Pregunta pregunta: preguntas) {
				fsalida.println(pregunta.getTexto());
				respuesta = fentrada.readLine();
				if(respuesta.equals("s")) {
					pregunta.sumarVotosSi();
				}else {
					pregunta.sumarVotosNo();
				}
			}
			
			fsalida.println(preguntas.toString());
		} catch (Exception e) {
			// TODO: handle exception
		}

	}
}
