package udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;

public class Actividad1x07B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		try {
			// creadno socket datagrama
			InetSocketAddress addr = new InetSocketAddress("localhost", 55000);
			DatagramSocket datagramSocket = new DatagramSocket(55000);
			
			String saludo = "hola";
		 
			InetAddress addr1 = InetAddress.getByName("localhost");
			DatagramPacket datagrama1 = new DatagramPacket(saludo.getBytes(), saludo.getBytes().length, addr1, 50000);
			// Enviar
			datagramSocket.send(datagrama1);
			System.out.println("Mensaje enviado");
			//Recibiendo mensaje
			byte[] mensaje = new byte[20];
			DatagramPacket datagrama2 = new DatagramPacket(mensaje, mensaje.length);
			datagramSocket.receive(datagrama2);
			
			String respuesta = new String(mensaje);
			System.out.println("Saludo: "+saludo);
			System.out.println("Respuesta: "+respuesta);
			datagramSocket.close();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
